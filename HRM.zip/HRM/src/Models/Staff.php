<?php

namespace Modules\HRM\Models;
 
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use Modules\HRM\Models\Department;
use Modules\HRM\Models\Designation;
use Modules\HRM\Models\StaffAddress;
use Modules\HRM\Models\StaffQualification;
use Modules\HRM\Models\StaffDocument;
use Modules\HRM\Models\StaffWorkExp;
use Modules\HRM\Models\AttendenceReport;


class Staff extends Model
{
    use HasFactory;
    protected $primaryKey = "staff_id";
    protected $fillable = [
        'employee_id',
        'user_id',
        'department_id',
        'designation_id',
        'gender',
        'staff_name',
        'staff_photo',
        'staff_email',
        'staff_phone',
        'date_of_joining',
        'date_of_leaving',
        'marital_status',
        'date_of_birth',
        'salary',
        'verification_status',
        'created_by',
        'updated_by',
    ];

    public function getTable(){
        return config('dbtable.common_staffs');
    }

    public function user(){
        return $this->belongsTo(User::class,'user_id','id');
    }
    
    public function department(){
        return $this->belongsTo(Department::class,'department_id','department_id');
    } 

    public function designation(){
        return $this->belongsTo(Designation::class,'designation_id','designation_id');
    }

    public function staff_address(){
        return $this->hasMany(StaffAddress::class,'staff_id','staff_id');
    }

    public function staff_document(){
        return $this->hasMany(StaffDocument::class,'staff_id','staff_id');
    }

    public function staff_qualification(){
        return $this->hasMany(StaffQualification::class,'staff_id','staff_id');
    }

    public function staff_experiance(){
        return $this->hasMany(StaffWorkExp::class,'staff_id','staff_id');
    }


    public function attendence(){
        return $this->belongsTo(AttendenceReport::class,'user_id', 'user_id');
    }

     public function leaves()
    {
        return $this->hasMany(Leave::class, 'user_id');
    }

}
