<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffWorkExp extends Model
{
    use HasFactory;
    protected $primaryKey = "experience_id";
    protected $fillable = [
        'staff_id',
        'company_name',
        'company_designation',
        'company_address',
        'contact_name',
        'contact_email',
        'staff_doc_id',
        'contact_phone',
        'date_of_joining',
        'date_of_leaving',
        'reason_for_leaving',
    ];

    public function getTable(){
        return config('dbtable.hrm_staff_experience');
    }

    public function document(){
        return $this->belongsTo(StaffDocument::class,'staff_doc_id','staff_doc_id');
    }

}
