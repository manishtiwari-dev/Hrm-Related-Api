<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use Modules\HRM\Models\Staff;


class AttendenceReport extends Model
{
    use HasFactory;
    
    // protected $fillable = [
    //     'user_id',
    //     'check_in',
    //     'check_out',
    //     'day',
    //     'month',
    //     'year',
    //     'attendance_date',
    // ];


    protected $primaryKey = 'id';


    protected $guarded = [
        'id'
      ];

    public function getTable(){
        return config('dbtable.hrm_attendances');
    }

    public function user(){
        return $this->belongsTo(User::class,'user_id', 'id');
    }

    public function user_list(){
        return $this->belongsTo(Staff::class,'user_id', 'user_id');
    }


}
