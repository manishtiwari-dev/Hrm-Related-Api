<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Education extends Model
{
    use HasFactory;
    protected $primaryKey = 'education_id';
    protected $fillable = [
        'education_name',
        'status',
    ];

    public function getTable(){
        return config('dbtable.hrm_education');
    }

}
