<?php

namespace Modules\HRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StaffQualification extends Model
{
    use HasFactory;
    protected $primaryKey = "qualification_id";
    protected $fillable = [
        'staff_id',
        'education_id',
        'university_name',
        'admission_at',
        'passing_at',
        'staff_doc_id',
        'status',
    ];
    
    public function getTable(){
        return config('dbtable.hrm_staff_qualification');
    }
    
    public function education(){
        return $this->belongsTo(Education::class,'education_id','education_id');
    }
    
    public function document(){
        return $this->belongsTo(StaffDocument::class,'staff_doc_id','staff_doc_id');
    }


}
