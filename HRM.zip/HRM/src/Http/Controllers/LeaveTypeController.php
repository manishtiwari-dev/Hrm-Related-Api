<?php

namespace Modules\HRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use ApiHelper;
use Modules\HRM\Models\Department;
use Modules\HRM\Models\LeaveType;
use Modules\HRM\Models\Role;
use Modules\HRM\Models\RoleToPermission;
use Illuminate\Support\Str;
use Validator;
use App\Models\User;
use Modules\HRM\Models\Leave;


class LeaveTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public $page = 'hrm-setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $list = LeaveType::all();
        //   $user_list =Leave::where('user_id',ApiHelper::get_user_id_from_token($api_token))->get();             

        $user_list = User::all();
        $res = [
            'leave_type' => $list,
            'user_list' => $user_list
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $validator = Validator::make($request->all(), [
            'leave_type_name' => 'required',
            'leave_info' => 'required',
            'no_of_days' => 'required',
        ], [
            'leave_type_name.required' => 'LEAVE_TYPE_NAME_REQUIRED',
            'leave_info.required' => 'LEAVE_TYPE_INFO_REQUIRED',
            'no_of_days.required' => 'NO_OF_DAYS_REQUIRED',
        ]);

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());


        $user_id = ApiHelper::get_adminid_from_token($api_token);

        $Insert = $request->only('leave_type_name', 'leave_info', 'no_of_days', 'max_allowed');
        // $Insert['created_by'] = $user_id;

        $res = LeaveType::create($Insert);
        if ($res)
            return ApiHelper::JSON_RESPONSE(true, $res, 'SUCCESS_LEAVE_TYPE_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_LEAVE_TYPE_ADD');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        //    $data_list = LeaveType::where('leave_type_id',$request->leave_type_id)->first();
        $leave_type = LeaveType::find($request->leave_type_id);


        $res = [
            'leave_type' => $leave_type,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $api_token = $request->api_token;
        $updateId = $request->leave_type_id;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $validator = Validator::make($request->all(), [
            'leave_type_name' => 'required',
            'leave_info' => 'required',
            'no_of_days' => 'required',
        ], [
            'leave_type_name.required' => 'LEAVE_TYPE_NAME_REQUIRED',
            'leave_info.required' => 'LEAVE_TYPE_INFO_REQUIRED',
            'no_of_days.required' => 'NO_OF_DAYS_REQUIRED',
        ]);

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());


        $user_id = ApiHelper::get_adminid_from_token($api_token);

        $Insert = $request->only('leave_type_name', 'leave_info', 'no_of_days', 'max_allowed');

        $res = LeaveType::where('leave_type_id', $updateId)->update($Insert);
        if ($res)
            return ApiHelper::JSON_RESPONSE(true, $res, 'SUCCESS_LEAVE_TYPE_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_LEAVE_TYPE_UPDATE');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $api_token = $request->api_token;
        $id = $request->deleteId;

        $status = LeaveType::where('leave_type_id', $id)->delete();
        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_LEAVE_TYPE_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_LEAVE_TYPE_DELETE');
        }
    }
}
